import 'dart:collection';

import 'package:Chalet/controller/list_item_handler.dart';
import 'package:Chalet/model/list_items.dart';
import 'package:Chalet/view/core/widgets_builder.dart';
import 'package:Chalet/view/external/datepicker_dialog.dart';
import 'package:flutter/material.dart';
import 'package:Chalet/model/items.dart';
import 'package:Chalet/model/model_fetch.dart';

class ItemsToWidgets extends StatefulWidget {
  final List<OmbrelloniItem> file;
  final MultipleCounter counter;

  ItemsToWidgets({required this.file, required this.counter});

  _ItemsToWidgetsState createState() => _ItemsToWidgetsState();
}

class _ItemsToWidgetsState extends State<ItemsToWidgets> {
  Map<int, Map<String, dynamic>>? _ombrellas;
  void initState() {
    _ombrellas = ombrelloniToFinalMap();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
        shrinkWrap: true,
        physics: const BouncingScrollPhysics(),
        children: widget.file.map((ListItem ombrellone) {
          widget.counter.addEntry(MapEntry(ombrellone, ombrellone.number));
          return ListContainerOmbrelloni(
            ombrelloneId: _ombrellas![ombrellone.number]!["id"],
            numFila: _ombrellas![ombrellone.number]!["fila"],
            numOmbrellone: _ombrellas![ombrellone.number]!["number"],
            item: ombrellone,
            counter: widget.counter,
            onPrenotaPressed: () {
              showDialog(
                      context: context,
                      builder: (context) => CustomDatePicker())
                  .whenComplete(() => setState(() {
                        addItem(ombrellone, widget.counter);
                      }));
            },
          );
        }).toList());
  }
}
