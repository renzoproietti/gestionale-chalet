import 'package:flutter/material.dart';

class VisualizzaPrenotazioni extends StatefulWidget {
  @override
  _VisualizzaPrenotazioniState createState() => _VisualizzaPrenotazioniState();
}

class _VisualizzaPrenotazioniState extends State<VisualizzaPrenotazioni> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
