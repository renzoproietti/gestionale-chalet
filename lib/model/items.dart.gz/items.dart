abstract class Item {
  final String id;

  const Item({required this.id});
}

class Ombrellone extends Item {
  final int fila;
  final int numero;

  const Ombrellone(
      {required String id, required this.fila, required this.numero})
      : super(id: id);
}

class Lettino extends Item {
  final double prezzo;

  const Lettino({required String id, required this.prezzo}) : super(id: id);
}

class Pietanza extends Item {
  final String nome;
  final double prezzo;

  const Pietanza({required String id, required this.nome, required this.prezzo})
      : super(id: id);
}

abstract class Prenotazione {
  final String id;

  const Prenotazione({required this.id});
}

class PrenotazioneSpiaggia extends Prenotazione {
  final String dateRange;

  const PrenotazioneSpiaggia({required String id, required this.dateRange})
      : super(id: id);
}

class PrenotazioneRistorante extends Prenotazione {
  final String time;

  const PrenotazioneRistorante({required String id, required this.time})
      : super(id: id);
}
