enum Categories {
  ombrelloni,
  lettini,
  ristorante,
}
