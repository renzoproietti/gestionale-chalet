import 'dart:collection';

import 'package:flutter/cupertino.dart';

import 'items.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> addOmbrellone({required String id, required int fila}) {
  CollectionReference ombrelloni =
      FirebaseFirestore.instance.collection('Ombrelloni');

  return ombrelloni
      .add({'id': id, 'fila': fila}).catchError((error) => print('$error'));
}

Future<List<Map<String, dynamic>>> fetchOmbrelloni() async {
  Query<Map<String, dynamic>> ombrelloni =
      FirebaseFirestore.instance.collection('Ombrelloni').orderBy('fila');

  QuerySnapshot<Map<String, dynamic>> querySnapshot = await ombrelloni.get();

  final List<Map<String, dynamic>> allData =
      querySnapshot.docs.map((doc) => doc.data()).toList();

  return allData;
}
