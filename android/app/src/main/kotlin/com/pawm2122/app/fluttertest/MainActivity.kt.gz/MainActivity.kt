package com.pawm2122.app.Chalet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
